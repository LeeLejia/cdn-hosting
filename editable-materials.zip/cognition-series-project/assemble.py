"""30fps lesson series. Editable voice-synchronized animation events and captions."""
from pathlib import Path
import json,math,re,subprocess,hashlib,datetime,shutil,concurrent.futures
from PIL import Image,ImageDraw,ImageFilter
from render import render,tween,transition_duration,cover,SCENES,EPISODES,C,ease
ROOT=Path(__file__).parent
OUT=ROOT.parent/'cognition_series_video'
FPS=30
REF=json.loads((ROOT/'source_reference.json').read_text())
def run(cmd):
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace')[-4000:])
    return p.stdout
def ts(sec,ass=False):
    if ass:
        c=round(sec*100);return f'{c//360000}:{c//6000%60:02d}:{c//100%60:02d}.{c%100:02d}'
    m=round(sec*1000);return f'{m//3600000:02d}:{m//60000%60:02d}:{m//1000%60:02d},{m%1000:03d}'
ASS='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans CJK SC,42,&H00FFFFFF,&H00000000,&H00362E10,&H00000000,0,0,0,0,100,100,0,0,1,0,0,2,100,100,37,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
def pieces(s):
    parts=re.findall(r'[^，。！？；：]+[，。！？；：]?',s);out=[];chunk=''
    for a in parts:
        while len(a)>30:
            if chunk:out.append(chunk);chunk=''
            out.append(a[:28]);a=a[28:]
        if len(chunk+a)>28 and chunk:out.append(chunk);chunk=''
        chunk+=a
    if chunk:out.append(chunk)
    return out
def cues_for(meta):
    out=[]
    for b in meta['boundaries']:
        start=b['offset']/1e7;end=min(meta['duration'],start+b['duration']/1e7)
        phrase=b['text'];chunks=pieces(phrase);count=sum(map(len,chunks));off=0
        for x in chunks:
            a=start+(end-start)*off/count;off+=len(x);z=start+(end-start)*off/count;out.append((a,z,x))
    return [(a,min(z,out[k+1][0]) if k+1<len(out) else z,x) for k,(a,z,x) in enumerate(out)]
def anchors_for(s,meta):
    starts=[b['offset']/1e7 for b in meta['boundaries']];dur=meta['duration'];n=s['source_scene']
    if s['visual']=='episode_end':return [0,dur*.34,dur*.68]
    if s['stage_sentences']:
        anchors=[0]+[starts[min(k,len(starts)-1)] for k in s['stage_sentences']]
    elif n is not None and s['narration']==REF['original_scenes'][n]['narration']:
        anchors=REF['original_timeline'][n]['visual_change'][:]
    else:
        changed={0:[2,3],8:[1,2],15:[2,3],22:[2,3],23:[1,3]}
        anchors=[0]+[starts[min(k,len(starts)-1)] for k in changed.get(n,[1,2])]
    if not .1<=anchors[1]<anchors[2]<dur-.3:
        anchors=[0,dur*.33,dur*.67]
    return anchors
def focus_event(base,u):
    """Illustrate reduced detail away from gaze, without implying a field measurement."""
    a=math.sin(math.pi*u)**.65
    crop=base.crop((96,214,1824,845));blurred=crop.filter(ImageFilter.GaussianBlur(5))
    mask=Image.new('L',crop.size,255);md=ImageDraw.Draw(mask)
    md.ellipse((476-96-136,779-214-136,476-96+136,779-214+136),fill=0)
    mask=mask.filter(ImageFilter.GaussianBlur(23));layer=Image.composite(blurred,crop,mask)
    im=base.copy();im.paste(Image.blend(crop,layer,a),(96,214));return im
def click_event(base,u):
    im=base.copy();d=ImageDraw.Draw(im);pulse=math.sin(math.pi*u);radius=24+25*u
    col=tuple(round(246+(c-246)*pulse) for c in (204,142,40))
    d.ellipse((476-radius,779-radius,476+radius,779+radius),outline=col,width=5)
    return im
def scene(i):
    s=SCENES[i];meta=json.loads((ROOT/f'audio/{i:03}.json').read_text());dur=math.ceil((meta['duration']+.5)*FPS)/FPS
    signature=hashlib.sha256((json.dumps(s,ensure_ascii=False)+meta['signature']+''.join((ROOT/n).read_text() for n in ['render.py','legacy.py','assemble.py'])).encode()).hexdigest()
    dest=ROOT/f'scenes/{i:03}.mp4';cache=dest.with_suffix('.render.json')
    valid=dest.exists() and cache.exists() and json.loads(cache.read_text()).get('signature')==signature
    anchors=anchors_for(s,meta);cues=cues_for(meta)
    ass=ASS+''.join(f'Dialogue: 0,{ts(a,True)},{ts(b,True)},Default,,0,0,0,,{x}\n' for a,b,x in cues)
    ap=ROOT/f'subtitles/{i:03}.ass';ap.write_text(ass)
    (ROOT/f'subtitles/{i:03}.srt').write_text('\n\n'.join(f'{k+1}\n{ts(a)} --> {ts(b)}\n{x}' for k,(a,b,x) in enumerate(cues))+'\n')
    keyframes=[render(i,p) for p in range(3)]
    for p,im in enumerate(keyframes):im.save(ROOT/f'frames/{i:03}_{p}.png')
    events=[]
    for p in [1,2]:
        td=min(transition_duration(s,p-1,p),(anchors[p+1] if p<2 else dur)-anchors[p]-.05)
        if keyframes[p-1].tobytes()!=keyframes[p].tobytes():events.append(dict(start=anchors[p],duration=max(.1,td),kind='state',before=p-1,after=p))
    if s['visual']=='near_error':
        b=next((b for b in meta['boundaries'] if '人眼只有' in b['text']),None)
        if b:events.append(dict(start=b['offset']/1e7+.3,duration=2.4,kind='gaze',before=0,after=0))
    if s['visual']=='hook':
        for t in [3.2,4.4,5.6]:events.append(dict(start=t,duration=.45,kind='click',before=0,after=0))
    events.sort(key=lambda x:x['start'])
    lines=['ffconcat version 1.0'];position=0;state=0
    def append(p,t):
        if t>.0001:lines.extend([f"file '{p.resolve()}'",f'duration {t:.8f}'])
    for k,event in enumerate(events):
        assert event['start']>=position-.01,(i,event,position)
        append(ROOT/f'frames/{i:03}_{state}.png',event['start']-position)
        count=max(3,round(event['duration']*FPS));event['duration']=count/FPS
        directory=ROOT/f'motion/{i:03}_{k}';directory.mkdir(parents=True,exist_ok=True)
        for j in range(count):
            png=directory/f'{j:03}.png'
            if not valid or not png.exists():
                u=(j+1)/count
                if event['kind']=='state':im=tween(i,event['before'],event['after'],u,keyframes)
                elif event['kind']=='gaze':im=focus_event(keyframes[state],u)
                else:im=click_event(keyframes[state],u)
                im.save(png,compress_level=1)
            append(png,1/FPS)
        position=event['start']+event['duration'];state=event['after']
    append(ROOT/f'frames/{i:03}_{state}.png',dur-position)
    lines.append(f"file '{ROOT}/frames/{i:03}_{state}.png'")
    f=ROOT/f'frames/{i:03}.ffconcat';f.write_text('\n'.join(lines)+'\n')
    if not valid:
        if dest.exists():
            old=ROOT/'revisions'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S')/'scenes';old.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,old/dest.name)
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-safe','0','-f','concat','-i',str(f),'-i',str(ROOT/f'audio/{i:03}.mp3'),'-vf',f'fps={FPS},ass={ap}:fontsdir={ROOT}/fonts','-map','0:v','-map','1:a','-t',f'{dur:.8f}','-c:v','libx264','-preset','veryfast','-tune','stillimage','-threads','2','-crf','24','-pix_fmt','yuv420p','-af','apad','-c:a','aac','-b:a','96k','-ar','48000','-movflags','+faststart',str(dest)])
    actual=float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(dest)]));cache.write_text(json.dumps(dict(signature=signature,duration=actual)))
    print(f'SCENE {i+1:02d}/{len(SCENES)} {actual:.1f}s {s["title"]}',flush=True)
    return dict(duration=actual,cues=cues,anchors=anchors,events=events)
def existing_results():
    results=[]
    for i,s in enumerate(SCENES):
        meta=json.loads((ROOT/f'audio/{i:03}.json').read_text());r=json.loads((ROOT/f'scenes/{i:03}.render.json').read_text());anchors=anchors_for(s,meta);dur=math.ceil((meta['duration']+.5)*FPS)/FPS;events=[]
        frames=[Image.open(ROOT/f'frames/{i:03}_{p}.png').convert('RGB') for p in range(3)]
        for p in [1,2]:
            if frames[p-1].tobytes()!=frames[p].tobytes():
                td=min(transition_duration(s,p-1,p),(anchors[p+1] if p<2 else dur)-anchors[p]-.05)
                events.append(dict(start=anchors[p],duration=max(3,round(max(.1,td)*FPS))/FPS,kind='state',before=p-1,after=p))
        if s['visual']=='near_error':
            b=next((b for b in meta['boundaries'] if '人眼只有' in b['text']),None)
            if b:events.append(dict(start=b['offset']/1e7+.3,duration=2.4,kind='gaze',before=0,after=0))
        if s['visual']=='hook':
            events.extend(dict(start=t,duration=round(.45*FPS)/FPS,kind='click',before=0,after=0) for t in [3.2,4.4,5.6])
        events.sort(key=lambda x:x['start'])
        results.append(dict(duration=r['duration'],cues=cues_for(meta),anchors=anchors,events=events))
    return results
def assemble(finalize_only=False):
    for n in ['scenes','frames','motion','subtitles']:(ROOT/n).mkdir(exist_ok=True)
    OUT.mkdir(exist_ok=True);stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');snapshot=ROOT/'revisions'/stamp/'source';snapshot.mkdir(parents=True,exist_ok=True)
    for n in ['author.py','storyboard.json','episodes.json','source_reference.json','render.py','legacy.py','speech.py','assemble.py']:shutil.copy2(ROOT/n,snapshot/n)
    if finalize_only:results=existing_results()
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(scene,range(len(SCENES))))
    timeline=[]
    for e in EPISODES:
        ep=e['number'];offset=0;subtitles=[];shots=[];metadata=f';FFMETADATA1\ntitle=认知与设计 {ep:02d}：{e["title"]}\n'
        for i in e['scenes']:
            s=SCENES[i];r=results[i];shots.append(dict(**s,start=offset,end=offset+r['duration'],animation_events=r['events'],state_anchors=r['anchors']))
            subtitles.extend((offset+a,offset+b,x) for a,b,x in r['cues'])
            metadata+=f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={round(offset*1000)}\nEND={round((offset+r["duration"])*1000)}\ntitle={s["title"]}\n';offset+=r['duration']
        assert 60<=offset<=300,(e['title'],offset)
        mp=ROOT/f'episode-{ep:02}.ffmetadata';mp.write_text(metadata)
        lst=ROOT/f'episode-{ep:02}.ffconcat';lst.write_text('ffconcat version 1.0\n'+'\n'.join(f"file '{ROOT}/scenes/{i:03}.mp4'" for i in e['scenes'])+'\n')
        final=OUT/e['filename']
        if final.exists():
            old=OUT/'revisions'/stamp;old.mkdir(parents=True,exist_ok=True);shutil.copy2(final,old/final.name)
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-safe','0','-f','concat','-i',str(lst),'-f','ffmetadata','-i',str(mp),'-map','0:v','-map','0:a','-map_metadata','1','-map_chapters','1','-c:v','copy','-af','loudnorm=I=-16:TP=-1.5:LRA=11','-c:a','aac','-b:a','96k','-ar','48000','-movflags','+faststart',str(final)])
        (OUT/f'{ep:02}-subtitles.srt').write_text('\n\n'.join(f'{k+1}\n{ts(a)} --> {ts(b)}\n{x}' for k,(a,b,x) in enumerate(subtitles))+'\n')
        (OUT/f'{ep:02}-讲稿.txt').write_text('\n\n'.join(SCENES[i]['title']+'\n'+SCENES[i]['narration'] for i in e['scenes'])+'\n')
        cover(ep,OUT/f'{ep:02}-cover.png')
        timeline.append({**e,'duration':offset,'scenes':shots});print(f'EPISODE {ep} {offset/60:.2f}min {final.stat().st_size/1e6:.1f}MB',flush=True)
    (OUT/'系列时间轴.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2))
if __name__=='__main__':
    import sys
    assemble(finalize_only='--finalize-only' in sys.argv)
