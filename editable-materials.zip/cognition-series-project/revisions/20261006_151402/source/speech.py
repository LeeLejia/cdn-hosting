import asyncio,json,os,subprocess,hashlib,shutil,datetime
from pathlib import Path
import edge_tts
slides=json.loads((Path(__file__).parent/"storyboard.json").read_text())
ROOT=Path(__file__).parent
VOICE='zh-CN-XiaoxiaoNeural'
RATE='+0%'
def signature(s):return hashlib.sha256((s['narration']+VOICE+RATE).encode()).hexdigest()
async def one(i,s,sem):
    async with sem:
        dest=ROOT/f'audio/{i:03d}.mp3'
        meta=dest.with_suffix('.json')
        if dest.exists() and meta.exists():
            if json.loads(meta.read_text()).get('signature')==signature(s):return
            archive=ROOT/'revisions'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S')/'audio'
            archive.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dest,archive/dest.name);shutil.copy2(meta,archive/meta.name)
        for attempt in range(4):
            try:
                boundaries=[]
                talk=edge_tts.Communicate(s['narration'],VOICE,rate=RATE,proxy=os.environ.get('HTTPS_PROXY'),boundary='SentenceBoundary')
                with dest.open('wb') as f:
                    async for item in talk.stream():
                        if item['type']=='audio':f.write(item['data'])
                        elif item['type']=='SentenceBoundary':boundaries.append({k:item[k] for k in ('offset','duration','text')})
                dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(dest)]))
                meta.write_text(json.dumps(dict(duration=dur,boundaries=boundaries,signature=signature(s),voice=VOICE,rate=RATE),ensure_ascii=False))
                print(f'VOICE {i+1:02d}/{len(slides)} {dur:.1f}s {s["title"]}',flush=True)
                return
            except Exception as e:
                print(f'RETRY {i} {type(e).__name__}',flush=True)
                await asyncio.sleep(1+attempt)
        raise RuntimeError(f'Voice failed: {i}')
async def main():
    (ROOT/'audio').mkdir(exist_ok=True)
    await asyncio.gather(*(one(i,s,async_sem) for i,s in enumerate(slides)))
async_sem=asyncio.Semaphore(3)
if __name__=='__main__':asyncio.run(main())
