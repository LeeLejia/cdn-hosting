"""Lesson artwork and restrained motion tied to explanatory changes."""
import json,math
from pathlib import Path
from PIL import Image,ImageDraw
import legacy as L
ROOT=Path(__file__).parent
SCENES=json.loads((ROOT/'storyboard.json').read_text())
EPISODES=json.loads((ROOT/'episodes.json').read_text())
W,H=1920,1080
L.C.update(bg='#F6F5F0',ink='#15343C',muted='#637A7C',line='#D9E4DF',teal='#007E78',soft='#E2F3EC',navy='#102E36',red='#B84042',redsoft='#FFF0EC')
C=L.C
text,box0,button,field,flightrow,centered=L.text,L.box,L.button,L.field,L.flightrow,L.centered
def box(d,r,fill='white',outline=None,radius=20,width=2):
    if fill=='white' and r[2]-r[0]>300 and r[3]-r[1]>150:
        x,y,z,w=r
        d.rounded_rectangle((x-2,y+4,z+2,w+12),radius=radius+3,fill='#E8EAE2')
        d.rounded_rectangle((x,y+4,z,w+8),radius=radius+1,fill='#E2E7DF')
    box0(d,r,fill,outline,radius,width)
L.box=box
def ease(u):return u*u*(3-2*u)
def chrome(im,s):
    d=ImageDraw.Draw(im)
    d.rectangle((0,0,W,199),fill=C['bg'])
    text(d,98,37,'认知与设计',27,'muted')
    # A small series position cue; no decorative moving progress meter.
    for k in range(4):
        x=354+45*k;d.rounded_rectangle((x,51,x+29,58),radius=3,fill=C['teal'] if k==s['episode']-1 else C['line'])
    box0(d,(1554,29,1824,86),'soft',radius=18)
    text(d,1580,36,f'{s["episode"]:02d}  /  {s["section"]}',28,'teal',True)
    d.rounded_rectangle((96,110,104,165),radius=4,fill=C['teal'])
    text(d,128,101,s['title'],52,'ink',True)
    L.line(d,(96,187),(1824,187))
    d.rectangle((0,956,W,H),fill=C['navy'])
    return im
def custom(s,p):
    im=Image.new('RGB',(W,H),C['bg']);d=ImageDraw.Draw(im);ep=s['episode']
    if s['visual']=='episode_open':
        box(d,(146,251,1124,845),'white');box(d,(1200,342,1780,735),'soft')
        if ep==2:
            text(d,190,275,'已选航班',30,'teal',True);flightrow(d,190,339,888,chosen=True)
            L.arrow(d,(637,487),(637,550),'muted');field(d,190,562,888,'下一页：证件号码','请输入完整证件号码')
            centered(d,1490,423,'时间？价格？',45,'ink',True)
            if p>=1:centered(d,1490,534,'刚才选了什么？',34,'red',True)
            if p==2:centered(d,960,868,'让界面接力，减少大脑接力',34,'teal',True)
        elif ep==3:
            text(d,190,294,'确认订单',36,'ink',True);text(d,190,386,'北京 → 上海',42,'ink',True);text(d,190,469,'应付 ¥ 960',46,'teal',True);button(d,(190,672,1080,765),'提交订单')
            centered(d,1490,422,'点到按钮',42,'ink',True)
            if p>=1:centered(d,1490,514,'≠ 任务完成',42,'red',True)
            if p==2:centered(d,960,868,'收到、处理中、结果，都应明确',34,'teal',True)
        else:
            text(d,190,294,'申请退票',36,'ink',True);text(d,190,392,'已付总额       ¥ 960',38);text(d,190,484,'退票费用       ¥ 200',38,'teal',True);L.line(d,(190,577),(1072,577));text(d,190,625,'预计退还       ¥ 760',42,'teal',True)
            centered(d,1490,422,'仅扣除 ¥ 200',34,'gold',True)
            if p>=1:centered(d,1490,536,'会损失 ¥ 200',34,'red',True)
            if p==2:centered(d,960,868,'事实相同，感受可能不同',34,'teal',True)
    else:
        e=EPISODES[ep-1];questions=['用户下一眼，会看哪里？','还有什么必须靠脑子记？','怎样确认事情真的办成？','这次取舍，减少了哪种成本？']
        paths=[['目标','线索','看见'],['上下文','识别','判断'],['动作','反馈','完成'],['原理','权衡','验证']]
        text(d,153,238,e['title'],30,'muted');text(d,153,324,questions[ep-1],60,'ink',True)
        for k,word in enumerate(paths[ep-1]):
            x=155+k*596;box(d,(x,516,x+420,720),'white','line');centered(d,x+210,576,word,47,'teal',True)
            if k<2:L.arrow(d,(x+446,618),(x+568,618),'teal' if p>k else 'dim')
        if p>=1:centered(d,960,816,s['title'],36,'teal',True)
    return chrome(im,s)
def render(i,p=0):
    s=SCENES[i]
    return custom(s,p) if s['visual'].startswith('episode_') else chrome(L.render(i,p),s)
def pointer(d,x,y):
    points=[(x,y),(x+3,y+50),(x+16,y+38),(x+30,y+57),(x+42,y+49),(x+29,y+31),(x+49,y+29)]
    d.polygon(points,fill='white',outline=C['ink']);d.line(points+[points[0]],fill=C['ink'],width=3)
def tween(i,a,b,u,frames):
    """Move the thing being explained; generic changes use a brief dissolve."""
    q=ease(u);s=SCENES[i];v=s['visual'];first,last=frames[a],frames[b]
    if u<=0:return first
    if u>=1:return last
    if v=='near_error' and (a,b)==(0,1):
        im=first.copy();d=ImageDraw.Draw(im);d.rectangle((298,303,1622,357),fill='white')
        x=298+q*20;y=303+q*377;width=1324-q*280
        box0(d,(x,y,x+width,y+53),'redsoft',radius=10);text(d,x+20,y+6,'手机号填写有误' if q<.6 else '!  请输入11位手机号码',27,'red',True)
        if q>.5:box0(d,(298,603,1358,673),None,'red',radius=12,width=3)
        if q>.83:im=Image.blend(im,last,(q-.83)/.17)
        return im
    if v=='grouping' and (a,b)==(0,1):
        im=first.copy();d=ImageDraw.Draw(im);box0(d,(996,284,1824,837),'white')
        for k in range(3):
            yy=342+k*146
            tint=tuple(round(255+(c-255)*q) for c in (226,243,236))
            box0(d,(1020,yy-18,1786,yy+94),tint,radius=14)
            text(d,1054,yy,['10:10 → 12:20','13:45 → 16:00','19:20 → 21:35'][k],32,'ink',True)
            text(d,1554,yy+68*(1-q),'¥ '+['760','850','920'][k],36,'teal',True)
        return im if q<.8 else Image.blend(im,last,(q-.8)/.2)
    if v=='consistency':
        im=first.copy();d=ImageDraw.Draw(im);d.rectangle((1325,631,1798,755),fill='white')
        going_bad=(b==1);delta=q if going_bad else 1-q
        for label,x0,x1,col,sign in [('返回',1344,1586,'muted',-1),('继续',1586,1344,'teal',1)]:
            x=x0+(x1-x0)*delta;y=654+math.sin(math.pi*q)*28*sign
            button(d,(x,y,x+194,y+76),label,col)
        if q>.8:im=Image.blend(im,last,(q-.8)/.2)
        return im
    if v=='target' and (a,b)==(0,1):
        im=first.copy();d=ImageDraw.Draw(im)
        rect=[1260+(1096-1260)*q,464+(407-464)*q,1560+(1724-1560)*q,530+(575-530)*q]
        box0(d,rect,None,'teal',radius=12+8*q,width=5)
        pointer(d,1010+410*q,690-200*q)
        return im if q<.8 else Image.blend(im,last,(q-.8)/.2)
    if v=='visible_summary' and (a,b)==(0,1):
        im=first.copy();piece=last.crop((1170,336,1610,837));im.paste(piece,(round(1780-610*q),336))
        return im if q<.82 else Image.blend(im,last,(q-.82)/.18)
    if v in ('visual_structure','recognition','calculation') and (a,b)==(0,1):
        im=first.copy();bottom=round(284+(837-284)*q);im.paste(last.crop((996,284,1824,bottom)),(996,284))
        return im if q<.85 else Image.blend(im,last,(q-.85)/.15)
    if v=='goal_filter' and (a,b)==(0,1):
        im=Image.blend(first,last,q);d=ImageDraw.Draw(im)
        x=218+850*q;y=342
        d.rounded_rectangle((x,y,x+180,y+67),radius=12,outline=C['gold'],width=5)
        return im if q<.85 else Image.blend(im,last,(q-.85)/.15)
    # Color -> grayscale and state feedback stay legible through a short dissolve.
    return Image.blend(first,last,q)
def transition_duration(s,a,b):
    v=s['visual']
    if v in ['near_error','grouping','consistency','target','goal_filter']:return 1.0
    if v=='visible_summary':return .85
    if v=='color_meaning' and b==2:return .8
    return .4
def cover(ep,path):
    e=EPISODES[ep-1];im=Image.new('RGB',(W,H),C['navy']);d=ImageDraw.Draw(im)
    text(d,140,105,'认知与设计',35,'#ADC3C0');text(d,140,265,e['title'],100,'white',True)
    question={'看见':'提示在眼前，为什么看不见？','理解':'让界面接力，让大脑少费力','完成':'点到按钮，怎样真正办成？','判断':'理解原理，再做出设计取舍'}[e['theme']]
    text(d,145,461,question,48,'#A9DCD3',True)
    d.rounded_rectangle((144,680,702,802),radius=25,fill=C['teal']);text(d,184,707,f'{ep:02d}  /  {e["theme"]}',47,'white',True)
    for k,yy in enumerate([293,449,605]):
        box0(d,(1228,yy,1778,yy+118),'#24444C',radius=24);text(d,1268,yy+28,['用户目标','认知原理','设计选择'][k],38,'white',True)
        if k<2:L.arrow(d,(1503,yy+130),(1503,yy+145),'teal',4)
    im.save(path)
if __name__=='__main__':
    p=ROOT/'preview';p.mkdir(exist_ok=True)
    for i in range(len(SCENES)):render(i,2).save(p/f'{i:03}.png')
