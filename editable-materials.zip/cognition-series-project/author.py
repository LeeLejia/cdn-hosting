"""Series edit: complete arguments in 1–5 minute episodes, not time-sliced excerpts."""
import json,shutil,hashlib
from pathlib import Path
ROOT=Path(__file__).parent
BASE=ROOT.parent/'cognition_v2_build'
if (BASE/'storyboard.json').exists():
    original=json.loads((BASE/'storyboard.json').read_text())
    old_anchors=json.loads((BASE/'章节与分镜.json').read_text())['scenes']
else:
    ref=json.loads((ROOT/'source_reference.json').read_text())
    original=ref['original_scenes'];old_anchors=ref['original_timeline']
scenes=[];episodes=[]
def add(ep,title,visual,narration,beats,sources,source=None,stage_sentences=None):
    scenes.append(dict(episode=ep,index=len(scenes),section=episodes[ep-1]['theme'],title=title,visual=visual,narration=narration,beats=beats,source_chapters=sources,source_scene=source,stage_sentences=stage_sentences))
def use(ep,n,narration=None):
    s=original[n]
    add(ep,s['title'],s['visual'],narration or s['narration'],s['beats'],s['source_chapters'],source=n)
def end(ep,title,narration):
    add(ep,title,'episode_end',narration,[title],[],stage_sentences=[1,2])
episodes.append(dict(number=1,theme='看见',title='让信息被看见',question='提示在眼前，为什么还是看不见？',filename='01-see-the-information.mp4'))
use(1,0,'一个人要订机票。页面明明用红字提示手机号填错了，他却连点三次提交，以为网站卡住了。设计师觉得提示已经很醒目，用户为什么还看不见？关键在于，屏幕上存在的信息，不等于人脑真的处理了它。')
for n in [2,3,4,5,6,7]:use(1,n)
end(1,'出现在下一眼，也符合此刻的目标','所以，检查信息是否可见，要从用户此刻的目标和视线出发。用结构表达关系，把提示放在下一眼会看的地方，再用少量、明确的线索传达重点。')

episodes.append(dict(number=2,theme='理解',title='减少理解负担',question='人还要记住什么，才能继续？',filename='02-reduce-mental-effort.mp4'))
add(2,'选完航班，还得在脑中接力？','episode_open','选好航班，下一步填写旅客信息。如果时间、价格和刚才的选择都消失了，用户就得一边填表，一边在脑中维持这些内容。怎样让这个流程少费脑？',['选择航班','填写旅客信息'],[7,8],stage_sentences=[1,2])
use(2,8,'工作记忆容量很小，而且需要注意力维持。填个证件号码，或者被消息打断，刚才记住的信息就可能丢失。这不是用户粗心，而是流程把信息接力的工作交给了大脑。')
for n in [9,10,11,12,13,14]:use(2,n)
end(2,'把上下文留在屏幕，把精力留给判断','减少认知负担，并不是让用户不思考。而是把中间状态留在屏幕，用熟悉选项帮助识别，用稳定规则帮助学习，把计算交给系统，让人专注于自己的选择。')

episodes.append(dict(number=3,theme='完成',title='让操作真正完成',question='按钮点了，事情就办成了吗？',filename='03-finish-the-task.mp4'))
add(3,'从点到按钮，到确认任务完成','episode_open','用户选好了机票，准备提交订单。按钮容易点到，只是第一步。他还需要知道系统有没有收到操作，最后有没有出票，结果又保存在哪里。',['提交订单','确认结果'],[8,13,14],stage_sentences=[1,2])
for n in [16,17,18,19,20]:use(3,n)
end(3,'点得到、知结果、能收尾','一个完整流程，要让用户点得到目标，等待时理解状态，结束时确认结果。系统接好收尾，用户才真的把事情做成。')

episodes.append(dict(number=4,theme='判断',title='帮助用户判断',question='理解了原理，怎样做出设计取舍？',filename='04-make-better-decisions.mp4'))
add(4,'同一笔费用，为什么改变了选择？','episode_open','机票买好了，用户想申请退票。同样收取两百元费用，写成仅扣除两百元，或者会损失两百元，可能影响他的选择。设计怎样帮助判断，而不只是推动点击？',['申请退票','理解选择后果'],[12],stage_sentences=[1,2])
use(4,15,'人做选择，并不总是理性计算。损失厌恶和措辞都会影响判断。把总价、退改条件和选择后果清楚地放在一起，比用情绪化文案催促决定更有帮助。设计应该支持用户判断，而不是利用偏差替他作决定。')
use(4,22,'理解认知原理，也不等于得到一套永远正确的布局。小屏幕上，把所有信息都展开，可能很难阅读；全部拆成独立页面，又会增加记忆负担。比较合理的办法，往往是让关键上下文始终可见，细节按需展开。准则之间会冲突，需要围绕真实任务权衡。理论的价值，是解释为什么要这样取舍。')
use(4,23,'最后，让一个第一次使用的人真正完成订票。观察他在哪里停顿，在哪里返回查信息，什么时候反复点击。别只问界面好不好看，而要看任务是否顺利。认知原理帮助我们提出有根据的改进，真实行为帮助我们判断改进有没有奏效。设计知识，就是在这种解释和验证中积累起来的。')
end(4,'解释取舍，再用真实任务验证','回到自己的设计，先问用户要付出哪些注意和记忆，再判断界面怎样分担这些成本。能解释取舍，还能用真实任务检验，准则才真正成为可用的知识。')

def main():
    for e in episodes:e['scenes']=[s['index'] for s in scenes if s['episode']==e['number']]
    (ROOT/'storyboard.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2))
    (ROOT/'episodes.json').write_text(json.dumps(episodes,ensure_ascii=False,indent=2))
    # Reuse the unchanged, accepted V2 voice without resynthesizing it.
    (ROOT/'audio').mkdir(exist_ok=True)
    for s in scenes:
        n=s['source_scene']
        if n is not None and s['narration']==original[n]['narration']:
            for ext in ['mp3','json']:
                p=BASE/f'audio/{n:03}.{ext}'
                if p.exists():shutil.copy2(p,ROOT/f'audio/{s["index"]:03}.{ext}')
    (ROOT/'source_reference.json').write_text(json.dumps(dict(original_scenes=original,original_timeline=old_anchors),ensure_ascii=False,indent=2))
    print(len(episodes),'episodes;',len(scenes),'scenes;',sum(len(s['narration']) for s in scenes),'narration characters')
if __name__=='__main__':main()
