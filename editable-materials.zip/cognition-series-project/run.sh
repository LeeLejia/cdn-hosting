#!/bin/sh
set -eu
cd "$(dirname "$0")"
python author.py
python speech.py
python assemble.py
