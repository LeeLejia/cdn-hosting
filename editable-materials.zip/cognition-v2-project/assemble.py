"""Build synchronized demonstrations, captions, chapter markers and editable timeline."""
from pathlib import Path
import json,math,subprocess,concurrent.futures,re,shutil,hashlib,datetime
from render import render,wrap,SCENES
ROOT=Path(__file__).parent
OUT=ROOT.parent/'cognition_v2_video'
FPS=12
# Semantic cues anchor each change to the sentence explaining it.
ANCHORS=[(9,13.9),(11.5,21.1),(8.4,20.6),(11.2,19.3),(4.7,18.8),(18.1,23.8),(10.4,21.5),(9.1,17.2),(14.4,18.8),(.1,18.9),(9.8,19.6),(9.7,14.2),(11.5,20.2),(10.9,21.7),(14.8,21.9),(14.6,23.5),(15.5,24.6),(10.5,22.5),(10.1,18.8),(8.9,15.3),(15.8,22.1),(2.8,13.7),(13.6,19.9),(4.6,14.7),(8.4,14.6)]
def run(cmd):
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace')[-4000:])
    return p.stdout
def ts(sec,ass=False):
    if ass:
        c=round(sec*100);return f'{c//360000}:{c//6000%60:02d}:{c//100%60:02d}.{c%100:02d}'
    m=round(sec*1000);return f'{m//3600000:02d}:{m//60000%60:02d}:{m//1000%60:02d},{m%1000:03d}'
ASS_HEAD='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans CJK SC,38,&H00FFFFFF,&H00000000,&H00352E14,&H00000000,0,0,0,0,100,100,0,0,1,0,0,2,100,100,38,1
Style: Click,Noto Sans CJK SC,72,&H00288ECC,&H00000000,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
def pieces(s):
    # Prefer clause boundaries; avoid keeping a dense whole paragraph on screen.
    parts=re.findall(r'[^，。！？；：]+[，。！？；：]?',s);out=[];chunk=''
    for a in parts:
        while len(a)>32:
            if chunk:out.append(chunk);chunk=''
            out.append(a[:30]);a=a[30:]
        if len(chunk+a)>30 and chunk:out.append(chunk);chunk=''
        chunk+=a
    if chunk:out.append(chunk)
    return out
def cues_for(meta):
    out=[]
    for b in meta['boundaries']:
        start=b['offset']/1e7;end=min(meta['duration'],start+b['duration']/1e7)
        phrase=b['text'].replace('认知与设计》','《认知与设计》')
        chunks=pieces(phrase);count=sum(map(len,chunks));off=0
        for x in chunks:
            a=start+(end-start)*off/count;off+=len(x);z=start+(end-start)*off/count;out.append((a,z,x))
    return [(a,min(z,out[k+1][0]) if k+1<len(out) else z,x) for k,(a,z,x) in enumerate(out)]
def scene(i):
    s=SCENES[i];meta=json.loads((ROOT/f'audio/{i:03d}.json').read_text());dur=math.ceil((meta['duration']+.7)*FPS)/FPS
    current=hashlib.sha256((json.dumps(s,ensure_ascii=False)+meta['signature']+(ROOT/'render.py').read_text()+(ROOT/'assemble.py').read_text()).encode()).hexdigest()
    dest=ROOT/f'scenes/{i:03d}.mp4';cache=dest.with_suffix('.render.json');valid=dest.exists() and cache.exists() and json.loads(cache.read_text()).get('signature')==current
    # Snap editorial anchors to actual speech boundaries, keeping edits portable to voice changes.
    starts=[b['offset']/1e7 for b in meta['boundaries']]
    anchors=[0]+[min(starts,key=lambda x:abs(x-a)) for a in ANCHORS[i]]
    if i==9:anchors[1]=0.5
    cues=cues_for(meta);ass=ASS_HEAD
    for a,b,x in cues:ass+=f'Dialogue: 1,{ts(a,True)},{ts(b,True)},Default,,0,0,0,,{x}\n'
    if i==0:
        # Three actual click cues, confined to the opening incident.
        for a in [3.2,4.5,5.8]:ass+=f'Dialogue: 0,{ts(a,True)},{ts(a+.45,True)},Click,,0,0,0,,{{\\pos(476,779)\\fad(40,180)}}○\n'
    if i==16:
        ass+=f'Dialogue: 0,{ts(anchors[1],True)},{ts(anchors[1]+2,True)},Click,,0,0,0,,{{\\move(1010,690,1420,490,0,900)}}●\n'
    ap=ROOT/f'subtitles/{i:03d}.ass';ap.write_text(ass)
    (ROOT/f'subtitles/{i:03d}.srt').write_text('\n\n'.join(f'{k+1}\n{ts(a)} --> {ts(b)}\n{x}' for k,(a,b,x) in enumerate(cues))+'\n')
    f=ROOT/f'frames/{i:03d}.ffconcat';lines=['ffconcat version 1.0']
    for p in range(3):
        png=ROOT/f'frames/{i:03d}_{p}.png'
        if not valid or not png.exists():render(i,p).save(png)
        lines.extend([f"file '{png}'",f'duration {(anchors[p+1] if p<2 else dur)-anchors[p]:.6f}'])
    lines.append(f"file '{ROOT}/frames/{i:03d}_2.png'");f.write_text('\n'.join(lines)+'\n')
    if not valid:
        if dest.exists():
            old=ROOT/'revisions'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S')/'scenes';old.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,old/dest.name)
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-safe','0','-f','concat','-i',str(f),'-i',str(ROOT/f'audio/{i:03d}.mp3'),'-vf',f'fps={FPS},ass={ap}:fontsdir={ROOT}/fonts','-map','0:v','-map','1:a','-t',f'{dur:.6f}','-c:v','libx264','-preset','veryfast','-tune','stillimage','-threads','2','-crf','24','-pix_fmt','yuv420p','-af','apad','-c:a','aac','-b:a','80k','-ar','48000','-movflags','+faststart',str(dest)])
    actual=float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(dest)]))
    cache.write_text(json.dumps(dict(signature=current,duration=actual)));print(f'SCENE {i+1:02d}/25 {actual:.1f}s',flush=True)
    return dict(duration=actual,cues=cues,anchors=anchors)
def assemble():
    for n in ['scenes','frames','subtitles']:(ROOT/n).mkdir(exist_ok=True)
    OUT.mkdir(exist_ok=True);snapshot=ROOT/'revisions'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S')/'source';snapshot.mkdir(parents=True,exist_ok=True)
    for n in ['author.py','storyboard.json','render.py','speech.py','assemble.py']:shutil.copy2(ROOT/n,snapshot/n)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(scene,range(len(SCENES))))
    offset=0;chapters=[];timeline=[];srt=[]
    for i,(s,r) in enumerate(zip(SCENES,results)):
        if not chapters or chapters[-1]['title']!=s['section']:chapters.append(dict(title=s['section'],start=offset))
        timeline.append(dict(**s,index=i,start=offset,end=offset+r['duration'],visual_change=r['anchors']))
        srt.extend((offset+a,offset+b,x) for a,b,x in r['cues']);offset+=r['duration']
    for k,ch in enumerate(chapters):ch['end']=chapters[k+1]['start'] if k+1<len(chapters) else offset
    (OUT/'章节与分镜.json').write_text(json.dumps(dict(duration=offset,chapters=chapters,scenes=timeline),ensure_ascii=False,indent=2))
    (OUT/'中文字幕.srt').write_text('\n\n'.join(f'{k+1}\n{ts(a)} --> {ts(b)}\n{x}' for k,(a,b,x) in enumerate(srt))+'\n')
    (OUT/'讲稿.txt').write_text('\n\n'.join(s['title']+'\n'+s['narration'] for s in SCENES)+'\n')
    metadata=';FFMETADATA1\ntitle=认知与设计：看见、理解、完成\n'
    for ch in chapters:metadata+=f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={round(ch["start"]*1000)}\nEND={round(ch["end"]*1000)}\ntitle={ch["title"]}\n'
    mp=ROOT/'chapters.ffmetadata';mp.write_text(metadata);lst=ROOT/'scenes.ffconcat';lst.write_text('ffconcat version 1.0\n'+'\n'.join(f"file '{ROOT}/scenes/{i:03d}.mp4'" for i in range(len(SCENES)))+'\n')
    final=OUT/'认知与设计_看见理解完成_V2.mp4'
    if final.exists():
        old=OUT/'revisions'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S');old.mkdir(parents=True,exist_ok=True);shutil.copy2(final,old/final.name)
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-safe','0','-f','concat','-i',str(lst),'-f','ffmetadata','-i',str(mp),'-map','0:v','-map','0:a','-map_metadata','1','-map_chapters','1','-c','copy','-movflags','+faststart',str(final)])
    print(f'COMPLETE {offset/60:.2f}min {final.stat().st_size/1e6:.1f}MB',flush=True)
if __name__=='__main__':assemble()
