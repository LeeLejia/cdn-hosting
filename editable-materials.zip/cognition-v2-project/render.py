"""Editable, narrative-led booking demonstrations. No chapter/bullet dump."""
import json,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent
SCENES=json.loads((ROOT/'storyboard.json').read_text())
W,H=1920,1080
C=dict(bg='#F1F3EF',ink='#162E35',muted='#62777C',line='#D6E0DD',white='#FFFFFF',teal='#087D79',soft='#E3F2ED',red='#BD4240',redsoft='#FFF0ED',gold='#CC8E28',goldsoft='#FFF3D9',dim='#C3CECB',navy='#142E35')
FONTS=Path('/usr/share/fonts/opentype/noto')
def font(n,b=False):
    local=ROOT/'fonts'/('NotoSansCJK-Bold.ttc' if b else 'NotoSansCJK-Regular.ttc')
    return ImageFont.truetype(str(local if local.exists() else FONTS/local.name),n,index=2)
def wrap(s,size,width,b=False):
    f=font(size,b);out=[];row=''
    for ch in s:
        if ch=='\n':out.append(row);row='';continue
        if row and f.getlength(row+ch)>width:out.append(row);row=ch
        else:row+=ch
    if row:out.append(row)
    return out
def text(d,x,y,s,size=32,color='ink',bold=False,width=None,spacing=12):
    rows=wrap(s,size,width,bold) if width else s.split('\n')
    for j,row in enumerate(rows):d.text((x,y+j*(size+spacing)),row,font=font(size,bold),fill=C.get(color,color))
    return len(rows)*(size+spacing)
def box(d,r,fill='white',outline=None,radius=20,width=2):
    d.rounded_rectangle(r,radius=radius,fill=C.get(fill,fill),outline=C.get(outline,outline) if outline else None,width=width)
def line(d,a,b,color='line',width=3):d.line([a,b],fill=C.get(color,color),width=width)
def arrow(d,a,b,color='teal',width=5):
    line(d,a,b,color,width);ang=math.atan2(b[1]-a[1],b[0]-a[0]);r=18
    pts=[b,(b[0]-r*math.cos(ang-.55),b[1]-r*math.sin(ang-.55)),(b[0]-r*math.cos(ang+.55),b[1]-r*math.sin(ang+.55))]
    d.polygon(pts,fill=C[color])
def tag(d,x,y,s,color='teal'):
    w=font(27,True).getlength(s)+40;box(d,(x,y,x+w,y+52),'soft' if color=='teal' else 'redsoft',radius=14);text(d,x+20,y+6,s,27,color,True)
def button(d,r,s,color='teal'):
    box(d,r,color,radius=14);x,y,x2,y2=r;text(d,(x+x2-font(30,True).getlength(s))/2,(y+y2-42)/2,s,30,'white',True)
def centered(d,cx,y,s,size=35,color='ink',bold=False):text(d,cx-font(size,bold).getlength(s)/2,y,s,size,color,bold)
def note(d,s,color='teal',y=863):centered(d,960,y,s,32,color,True)
def panels(d,left='调整前',right='调整后'):
    tag(d,110,215,left,'red');tag(d,998,215,right)
    box(d,(96,284,924,837),'white');box(d,(996,284,1824,837),'white')
def field(d,x,y,w,label,value,err=False):
    text(d,x,y,label,28,'muted');box(d,(x,y+48,x+w,y+118),'redsoft' if err else 'white','red' if err else 'line',radius=12,width=3)
    text(d,x+22,y+61,value,31,'ink')
def flightrow(d,x,y,w,t='10:10',arrival='12:20',price='760',chosen=False):
    box(d,(x,y,x+w,y+132),'soft' if chosen else 'white','teal' if chosen else 'line',radius=16,width=3)
    text(d,x+26,y+20,t,42,'ink',True);text(d,x+180,y+30,'→',35,'muted');text(d,x+244,y+20,arrival,42,'ink',True)
    text(d,x+26,y+81,'北京首都',25,'muted');text(d,x+244,y+81,'上海虹桥',25,'muted')
    text(d,x+w-230,y+22,'¥ '+price,42,'teal',True);text(d,x+w-218,y+83,'票价',24,'muted')
def summary(d,x,y,w=410,h=452):
    box(d,(x,y,x+w,y+h),'soft',radius=18);text(d,x+28,y+24,'已选行程',30,'teal',True)
    text(d,x+28,y+87,'北京 → 上海',34,'ink',True);text(d,x+28,y+142,'10:10 — 12:20',32)
    line(d,(x+28,y+207),(x+w-28,y+207));text(d,x+28,y+235,'票价＋税费＋行李',27,'muted')
    text(d,x+28,y+285,'应付 ¥ 960',40,'teal',True);text(d,x+28,y+375,'返回修改行程',26,'teal')
def booking(d,good=False,summary_on=False,focus=False,coloronly=False,gray=False):
    box(d,(248,220,1672,836),'white');text(d,298,245,'填写旅客信息',33,'ink',True)
    if not good and not coloronly:box(d,(298,303,1622,356),'redsoft',radius=10);text(d,322,310,'手机号填写有误',27,'red')
    fw=760 if summary_on else 1060
    field(d,298,390,fw,'旅客姓名','林珊')
    field(d,298,555,fw,'手机号码','138 1234 567',good or coloronly)
    if good:text(d,318,680,'!  请输入11位手机号码',27,'red' if not gray else 'ink',True)
    button(d,(298,744,650,810),'继续订票')
    if summary_on:summary(d,1182,347,410,463)
    if focus:
        d.ellipse((430,738,515,821),outline=C['gold'],width=6);text(d,716,759,'点击后，视线仍在这里',30,'gold',True);arrow(d,(700,781),(535,781),'gold')
def process(d,phase,labels=('请求已收到','正在出票','出票成功')):
    xs=[400,960,1520]
    for k in range(2):arrow(d,(xs[k]+156,510),(xs[k+1]-150,510),'teal' if phase>k else 'dim')
    for k,x in enumerate(xs):
        active=k<=phase;box(d,(x-170,405,x+170,618),'soft' if active else 'white','teal' if active else 'line',radius=24,width=3)
        centered(d,x,438,str(k+1),38,'teal' if active else 'muted',True);centered(d,x,522,labels[k],30,'ink' if active else 'muted',True)
def render(i,p=0,t=0):
    s=SCENES[i];v=s['visual'];im=Image.new('RGB',(W,H),C['bg']);d=ImageDraw.Draw(im)
    text(d,96,42,'认知与设计',27,'muted');text(d,1710,42,s['section'],27,'teal',True)
    text(d,96,98,s['title'],52,'ink',True);line(d,(96,181),(1824,181))
    if v in ('hook','near_error','color_meaning'):
        good=(v=='near_error' and p>=1) or (v=='color_meaning' and p>=1)
        booking(d,good=good,focus=v!='color_meaning' and (p<2 if v=='hook' else p==0),coloronly=v=='color_meaning' and p==0,gray=v=='color_meaning' and p==2)
        if v=='hook' and p>=1:tag(d,1373,360,'提示离视线太远','red');arrow(d,(1420,715),(1420,362),'red')
        if v=='near_error' and p==2:note(d,'既指出问题，也给出修正方法')
        if v=='color_meaning' and p==2:
            im=im.convert('L').convert('RGB');d=ImageDraw.Draw(im);note(d,'没有颜色，仍能理解错误',color='ink')
    elif v=='thesis':
        centered(d,960,257,'用户的目标：订到合适的机票',44,'teal',True)
        names=['寻找','记忆','推算','猜测'] if p==0 else ['看见','理解','完成']
        n=len(names);left=180;gap=42;w=(1560-gap*(n-1))/n
        for k,x in enumerate(names):
            a=left+k*(w+gap);box(d,(a,418,a+w,665),'white','line');centered(d,a+w/2,482,x,48,'muted' if p==0 else 'teal',True)
        if p==2:note(d,'让界面承担负担，把精力留给选择',y=766)
    elif v=='goal_filter':
        box(d,(150,225,1770,841),'white');text(d,192,251,'北京 → 上海',36,'ink',True)
        for k,args in enumerate([('10:10','12:20','760'),('13:45','16:00','850'),('19:20','21:35','920')]):flightrow(d,196,320+k*156,1090,*args,chosen=p>=1 and k==0)
        for k,tx in enumerate(['会员专区','旅行灵感','限时抽奖']):
            box(d,(1336,320+k*156,1724,452+k*156),'goldsoft' if p==0 else 'bg');centered(d,1530,360+k*156,tx,31,'gold' if p==0 else 'dim',True)
        if p==2:note(d,'是否醒目，取决于此刻的目标')
    elif v=='visual_structure':
        panels(d,'混成一段文字','固定位置，便于比较')
        text(d,134,350,'北京至上海的航班，第一班上午10点10分出发，12点20分到达，票价760元；第二班13点45分出发，16点到达，票价850元；第三班19点20分出发，21点35分到达，票价920元。',34,width=738,spacing=26)
        if p>=1:
            for k,args in enumerate([('10:10','12:20','760'),('13:45','16:00','850'),('19:20','21:35','920')]):flightrow(d,1024,321+k*156,772,*args,chosen=p==2 and k==0)
        else:centered(d,1410,491,'需要先读完，才能比较',34,'muted')
        if p==2:note(d,'信息相同，寻找差异的成本不同')
    elif v=='grouping':
        panels(d,'关系模糊','分组符合实际关系')
        for side,x in enumerate([132,1032]):
            for k in range(3):
                yy=342+k*146
                if side==1 and p>=1:box(d,(x-12,yy-18,x+754,yy+94),'soft',radius=14)
                text(d,x+22,yy,['10:10 → 12:20','13:45 → 16:00','19:20 → 21:35'][k],32,'ink',True)
                # Ambiguous equal-distance gaps at left; correctly enclosed on right.
                text(d,x+522,yy+(68 if side==0 else 0),'¥ '+['760','850','920'][k],36,'teal',True)
        if p>=1:note(d,'靠近与相似，都会被理解为关系')
    elif v=='attention_budget':
        panels(d,'每一处都想被注意','给信号建立优先级')
        for k,tx in enumerate(['限时推荐','手机号填写有误','会员优惠','确认要继续吗？']):
            box(d,(136,330+k*112,884,413+k*112),'redsoft','red',radius=12);text(d,165,348+k*112,tx,31,'red',True)
        if p>=1:
            text(d,1044,337,'填写旅客信息',32,'ink',True);field(d,1044,420,728,'手机号码','138 1234 567',True);text(d,1064,562,'!  请输入11位手机号码',28,'red',True);button(d,(1044,684,1775,760),'继续订票')
        if p==2:note(d,'打断操作，是需要节制的资源')
    elif v in ('memory_gap','visible_summary'):
        if v=='memory_gap':
            panels(d,'上一页：选择航班','下一页：填写信息');flightrow(d,132,390,756,chosen=True);text(d,170,581,'选择后，时间和费用消失',31,'red')
            field(d,1034,341,742,'旅客姓名','林珊');field(d,1034,526,742,'证件号码','请填写证件号码')
            if p>=1:box(d,(1240,688,1654,785),'goldsoft');centered(d,1447,710,'刚才选的是哪一班？',29,'gold',True)
        else:
            box(d,(248,220,1672,836),'white');text(d,298,255,'填写旅客信息',34,'ink',True);field(d,298,354,756,'旅客姓名','林珊');field(d,298,523,756,'证件号码','110…');button(d,(298,744,650,810),'继续订票')
            if p>=1:summary(d,1182,348,410,462)
            if p==2:note(d,'把上下文留在屏幕上，随时确认')
    elif v=='recognition':
        panels(d,'凭空回忆，再输入','看到熟悉选项，再识别')
        field(d,134,342,754,'旅客姓名','请输入');field(d,134,528,754,'证件号码','请输入完整号码')
        if p>=1:
            for k,(name,ID) in enumerate([('林珊','证件尾号 0826'),('周宁','证件尾号 2158')]):
                box(d,(1034,342+k*174,1786,486+k*174),'soft' if k==0 else 'white','teal' if k==0 else 'line',width=3);text(d,1072,359+k*174,name,36,'ink',True);text(d,1072,423+k*174,ID,27,'muted');text(d,1684,382+k*174,'✓' if k==0 else '○',42,'teal')
        if p==2:note(d,'必要输入，提供示例或自动补全')
    elif v=='consistency':
        for k,x in enumerate([108,710,1312]):
            box(d,(x,278,x+500,774),'white');centered(d,x+250,319,['选择航班','填写信息','确认订单'][k],32,'ink',True)
            for j in range(3):box(d,(x+36,415+j*58,x+464,444+j*58),'bg',radius=5)
            swapped=p==1 and k==2
            button(d,(x+32,654,x+226,730),'继续' if swapped else '返回','teal' if swapped else 'muted');button(d,(x+274,654,x+468,730),'返回' if swapped else '继续','muted' if swapped else 'teal')
            if swapped:box(d,(x+16,641,x+484,744),fill=None,outline='red',radius=17,width=5)
        note(d,'操作规则稳定，经验才能复用' if p==2 else '同类动作，形成位置预期')
    elif v=='recovery':
        box(d,(328,234,1592,834),'white');text(d,382,275,'修改航班',38,'ink',True)
        text(d,382,374,'原行程：10:10 → 12:20',35);text(d,382,446,'新行程：13:45 → 16:00',35,'teal',True)
        if p>=1:
            box(d,(382,539,1538,666),'goldsoft');text(d,415,556,'确认后将补付 ¥ 50',32,'gold',True);text(d,415,610,'退改条件：确认前可返回修改',27)
        button(d,(382,714,872,794),'返回修改','muted');button(d,(1048,714,1538,794),'确认更改')
        if p==2:note(d,'先预览后果，保留恢复路径')
    elif v=='plain_language':
        panels(d,'内部术语','用户任务')
        text(d,158,382,'校验失败',45,'red',True);text(d,158,479,'状态码：E102',32,'muted');text(d,158,620,'？ 我该做什么',35,'muted')
        if p>=1:
            text(d,1058,382,'请检查证件号码',42,'teal',True);text(d,1058,479,'请输入18位身份证号码',31);text(d,1058,620,'定位问题 → 直接修正',32,'teal',True)
        if p==2:note(d,'短、具体、熟悉，服务下一步判断')
    elif v=='calculation':
        panels(d,'需要用户心算','系统计算，解释组成')
        for k,tx in enumerate(['票价              ¥ 760','税费              ¥ 120','行李              ¥ 80']):text(d,158,357+k*97,tx,37)
        centered(d,510,697,'合计是多少？',38,'red',True)
        if p>=1:
            text(d,1058,344,'实际应付',30,'muted');text(d,1058,399,'¥ 960',72,'teal',True);line(d,(1058,519),(1760,519));text(d,1058,560,'760 ＋ 120 ＋ 80',39);text(d,1058,678,'票价、税费、行李已计入',29,'muted')
        if p==2:note(d,'让用户比较方案，不必替系统算账')
    elif v=='decision_frame':
        panels(d,'措辞影响感受','让选择后果清楚可见')
        box(d,(136,345,884,490),'goldsoft');text(d,174,386,'仅扣除 ¥ 200',43,'gold',True)
        box(d,(136,548,884,693),'redsoft');text(d,174,589,'会损失 ¥ 200',43,'red',True)
        if p>=1:
            text(d,1042,341,'申请退票',38,'ink',True);text(d,1042,438,'已付总额        ¥ 960',34);text(d,1042,513,'退票费用        ¥ 200',34);line(d,(1042,587),(1765,587));text(d,1042,619,'预计退还        ¥ 760',39,'teal',True)
        if p==2:note(d,'同一事实，避免只靠情绪化措辞推动决定')
    elif v=='target':
        panels(d,'只有文字可点','合理的实际点击区域')
        for x in [196,1096]:
            box(d,(x,407,x+628,575),'soft','line');centered(d,x+314,457,'继续订票',44,'teal',True)
        box(d,(385,465,635,532),fill=None,outline='red',radius=6,width=4);text(d,230,656,'实际热区过小',32,'red',True)
        if p>=1:
            box(d,(1096,407,1724,575),fill=None,outline='teal',radius=20,width=5);text(d,1170,656,'按钮整体都能点击',32,'teal',True)
        if p==2:note(d,'目标更容易命中，邻近操作不易误触')
    elif v=='action_feedback':
        process(d,p)
        note(d,['收到请求 ≠ 完成目标','处理中，应说明当前状态','结果明确，行动循环才能闭合'][p],y=748)
    elif v=='responsiveness':
        panels(d,'计算中，没有反馈','计算中，及时回应')
        text(d,154,340,'点击后，画面没有变化',34,'muted');button(d,(154,647,864,730),'继续订票')
        centered(d,510,500,'是没点到，还是卡住了？',34,'red',True)
        if p>=1:
            box(d,(1044,339,1776,589),'soft');text(d,1076,370,'请求已收到',40,'teal',True);text(d,1076,455,'正在出票，请勿重复提交',29)
            text(d,1076,515,'订单状态会在这里更新',27,'muted');button(d,(1044,647,1776,730),'正在处理','muted')
        if p==2:note(d,'计算可以需要时间，反馈必须及时可见')
    elif v=='honest_wait':
        panels(d,'看似精确，实际未知','真实状态与可用退路')
        text(d,142,359,'出票进度 99%',42,'red',True);box(d,(142,472,878,514),'redsoft',radius=10);box(d,(142,472,870,514),'red',radius=10);text(d,142,604,'始终停在这里…',31,'muted')
        if p>=1:
            text(d,1042,355,'正在向航空公司确认',38,'teal',True);text(d,1042,463,'提交已收到，请勿重复提交',28);text(d,1042,557,'你可以离开此页，稍后查看订单',28,width=700);button(d,(1042,689,1776,777),'后台处理，返回订单')
        if p==2:note(d,'无法估算时，说明状态；允许时，提供取消')
    elif v=='finish':
        box(d,(322,237,1598,834),'white');tag(d,379,280,'出票成功');text(d,379,374,'北京 → 上海',48,'ink',True);text(d,379,455,'10:10 — 12:20',39)
        if p>=1:
            box(d,(379,541,1538,666),'soft');text(d,414,558,'行程与订单已保存',34,'teal',True);text(d,414,612,'可在“我的订单”中再次查看',29)
        button(d,(379,715,864,794),'查看行程');button(d,(1053,715,1538,794),'返回我的订单','muted')
        if p==2:note(d,'主任务完成，收尾不要再依赖用户记忆')
    elif v=='synthesis':
        labels=['找得到航班','记得住上下文','算得清总额','确认出票结果']
        values=['固定结构','行程摘要','实际应付 ¥960','状态与结果']
        for k in range(4):
            x=104+k*450;box(d,(x,297,x+412,752),'white','line');centered(d,x+206,343,labels[k],30,'ink',True)
            if p>=1:
                centered(d,x+206,446,values[k],27,'teal',True);centered(d,x+206,555,'↓',48,'teal');centered(d,x+206,651,['减少寻找','减少记忆','减少计算','减少猜测'][k],31,'teal',True)
        if p==2:note(d,'共同目标：让有限的注意力用在真正的决定上')
    elif v=='tradeoff':
        panels(d,'全部塞在一页','拆分，但保留关键上下文')
        for k in range(7):
            box(d,(139,325+k*60,881,372+k*60),'bg',radius=6);text(d,157,333+k*60,['航班信息','旅客信息','行李选项','费用明细','退改说明','发票信息','保险选项'][k],26,'muted')
        if p>=1:
            box(d,(1030,325,1790,419),'soft');text(d,1054,341,'北京 → 上海   |   应付 ¥960',29,'teal',True)
            text(d,1030,468,'本步：填写旅客信息',33,'ink',True);field(d,1030,533,760,'旅客姓名','林珊');text(d,1030,703,'费用明细、退改说明  ›',28,'teal')
        if p==2:note(d,'理解认知成本，才能判断怎样取舍')
    elif v=='user_test':
        box(d,(154,235,1766,838),'white');tag(d,198,276,'任务：为明天订一张合适的机票')
        for k,(a,b) in enumerate([('停顿','不知道总价是否包含行李'),('返回','忘了上一页所选的时间'),('重复提交','没有看到处理中状态')]):
            yy=405+k*128;text(d,210,yy,a,38,'gold',True);arrow(d,(443,yy+33),(549,yy+33),'muted')
            if p>=1:text(d,602,yy+3,b,35)
        if p==2:note(d,'观察行为，再验证修改是否减少了这些困难')
    elif v=='closing':
        for k,(a,b) in enumerate([('看见','下一眼会看哪里？'),('理解','还要记住或推算什么？'),('完成','怎样知道已经办成？')]):
            yy=275+k*175;box(d,(182,yy,1738,yy+144),'white');text(d,225,yy+34,a,43,'teal',True)
            if k<=p:text(d,546,yy+36,b,40,'ink',True)
        if p==2:note(d,'让人用有限的注意力和记忆，顺利把事情做成')
    else:raise ValueError(v)
    # Reserved, high-contrast subtitle band. It contains no unrelated information.
    d.rectangle((0,956,W,H),fill=C['navy'])
    return im
if __name__=='__main__':
    (ROOT/'preview').mkdir(exist_ok=True)
    for i in range(len(SCENES)):
        for p in range(3):render(i,p).save(ROOT/f'preview/{i:03d}_{p}.png')
